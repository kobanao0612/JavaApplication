package org.example;

//抽象クラス
public abstract class Food {
    int price;
    String madeIn;

    abstract String getDetail();


    boolean isMadeInJapan() {
        if(this.madeIn.equals("japan")) {
            return true;
        } else {
            return false;
        }
    }




    @Override
    public String toString() {
        return "果物の値段は" + this.price + "円です。";
    }

}