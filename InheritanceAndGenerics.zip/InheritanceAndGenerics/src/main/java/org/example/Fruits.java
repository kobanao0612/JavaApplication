package org.example;

import java.util.Objects;

public class Fruits extends Food {
    String color;

    Fruits(int price, String madeIn, String color) {
        this.price = price;
        this.madeIn = madeIn;
        this.color = color;
    }

    @Override
    String getDetail() {
        return "生産地" + this.madeIn + "色:" + this.color;
    }

    @Override
    public String toString() {
        return "果物の値段は" + this.price + "円です。";
    }

    @Override
    public boolean equals(Object o) {
        if(this.getClass() != o.getClass()) {
            return false;
        } else {
            Fruits f = (Fruits) o;
            if(this.color.equals(f.color) &&
                    this.madeIn.equals(f.madeIn) &&
                    this.price == f.price
            ) {return true;}
            else {return false;}
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(price, color, madeIn);
    }
}