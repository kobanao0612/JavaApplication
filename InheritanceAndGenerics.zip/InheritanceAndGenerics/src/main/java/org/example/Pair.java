package org.example;


import java.util.ArrayList;
import java.util.List;

//型パラメータを持つクラス
public class Pair<T> {
	public T first;
	public T second;

	public Pair(T first, T second) {
		this.first = first;
		this.second = second;
	}

	// [1,2,3],[3,4] -> [1,2,3,3,4]
	// [1.1,2.1,3.1],[3.1,4.1] -> [1,2,3,3,4]
	public static <A> ArrayList<A> merge(List<A> arr1, List<A> arr2) {
		ArrayList<A> result = new ArrayList<>();
		for(A e : arr1) {
			result.add(e);
		}
		for(A e : arr2) {
			result.add(e);
		}
		return result;
	}

	@Override
	public String toString() {
		return "(" + this.first +
				"," + this.second + ")";
	}
}
