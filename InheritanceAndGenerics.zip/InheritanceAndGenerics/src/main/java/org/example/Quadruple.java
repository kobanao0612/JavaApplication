package org.example;

public class Quadruple<T> {
	private T first;
	private T second;
	private T third;
	private T fourth;

	Quadruple(T first, T second, T third, T fourth){
		this.first = first;
		this.second = second;
		this.third = third;
		this.fourth = fourth;
	}

	//ジェネリックメソッド
	public static <X> Quadruple<X> getQuadrupleBy(Pair<Pair<X>> pairPair) {
		return new Quadruple<X>(
				pairPair.first.first,
				pairPair.first.second,
				pairPair.second.first,
				pairPair.second.second
				);
	}

	@Override
	public String toString() {
		return "(" + this.first +
				"," + this.second +
				"," + this.third +
				"," + this.fourth +
				")";
	}
}

